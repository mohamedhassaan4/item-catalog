from sqlalchemy import *
#-----------------------------------------------------
from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
from flask import url_for
from flask import jsonify
from database_setup import Base 
from database_setup import Category
from database_setup import CategoryItem
from sqlalchemy.orm import sessionmaker
engine = create_engine('sqlite:///catalog.db')
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()
session.query(Category).delete()
session.query(CategoryItem).delete()
sample_categories = ['sports', 'entertainment', 'tech']

for category_name in sample_categories:
    category = Category(category_name)
    session.add(category)
session.commit()
sample_items = {'bat': 1, 'TV': 2, 'computer': 3}

for item_title, item_category in sample_items.iteritems():
    item = CategoryItem(item_title, "Sample description", item_category)
    session.add(item)
session.commit()
